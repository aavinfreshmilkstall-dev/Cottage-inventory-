import React, { useState, useEffect } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { RawMaterialsManager } from './components/RawMaterialsManager';
import { ProductSOPManager } from './components/ProductSOPManager';
import { ProductionBatchManager } from './components/ProductionBatchManager';
import { FinishedGoodsManager } from './components/FinishedGoodsManager';
import { SalesManager } from './components/SalesManager';
import { SuppliersManager } from './components/SuppliersManager';
import { InvoiceModal } from './components/InvoiceModal';
import { SettingsModal } from './components/SettingsModal';

import {
  RawMaterial,
  ProductSOP,
  FinishedGood,
  ProductionBatch,
  SaleInvoice,
  PurchaseRecord,
  Supplier,
  BusinessProfile
} from './types';
import {
  loadDatabase,
  saveDatabase,
  resetToDemoDatabase,
  AppDatabase
} from './utils/storage';

export default function App() {
  const [db, setDb] = useState<AppDatabase>(() => loadDatabase());
  const [currentTab, setCurrentTab] = useState<TabType>('dashboard');

  // Modal states
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [activeInvoiceModal, setActiveInvoiceModal] = useState<SaleInvoice | null>(null);

  // Preloaded cross-navigation states
  const [preloadedSopId, setPreloadedSopId] = useState<string | undefined>(undefined);
  const [preloadedRawMatId, setPreloadedRawMatId] = useState<string | undefined>(undefined);

  // Save changes to localStorage whenever db changes
  useEffect(() => {
    saveDatabase(db);
  }, [db]);

  // Handlers for Raw Materials
  const handleSaveRawMaterial = (material: RawMaterial) => {
    const existingIndex = db.rawMaterials.findIndex(m => m.id === material.id);
    let updatedMaterials = [...db.rawMaterials];
    if (existingIndex > -1) {
      updatedMaterials[existingIndex] = material;
    } else {
      updatedMaterials.unshift(material);
    }
    setDb(prev => ({ ...prev, rawMaterials: updatedMaterials }));
  };

  const handleDeleteRawMaterial = (id: string) => {
    setDb(prev => ({
      ...prev,
      rawMaterials: prev.rawMaterials.filter(m => m.id !== id)
    }));
  };

  const handleRecordPurchase = (purchase: PurchaseRecord) => {
    setDb(prev => ({
      ...prev,
      purchases: [purchase, ...prev.purchases]
    }));
  };

  const handleAdjustRawStock = (id: string, newStock: number, reason: string) => {
    setDb(prev => ({
      ...prev,
      rawMaterials: prev.rawMaterials.map(m =>
        m.id === id ? { ...m, currentStock: newStock, notes: `${m.notes ? m.notes + '. ' : ''}[Adjusted: ${reason}]` } : m
      )
    }));
  };

  // Handlers for SOPs
  const handleSaveSOP = (sop: ProductSOP) => {
    const existingIndex = db.sops.findIndex(s => s.id === sop.id);
    let updatedSops = [...db.sops];
    if (existingIndex > -1) {
      updatedSops[existingIndex] = sop;
    } else {
      updatedSops.unshift(sop);
    }

    // Ensure matching finished good exists or gets updated
    let updatedFinished = [...db.finishedGoods];
    const fgIndex = updatedFinished.findIndex(f => f.sopId === sop.id);
    if (fgIndex > -1) {
      updatedFinished[fgIndex] = {
        ...updatedFinished[fgIndex],
        name: sop.name,
        code: sop.code,
        category: sop.category,
        packageSize: sop.packageSize,
        unitCost: sop.costPerUnit,
        wholesalePrice: sop.wholesalePrice,
        retailMRP: sop.retailMRP,
        unitOfSale: sop.unitOfSale
      };
    } else {
      updatedFinished.push({
        id: `fg-${Date.now().toString(36)}`,
        sopId: sop.id,
        name: sop.name,
        code: sop.code,
        category: sop.category,
        packageSize: sop.packageSize,
        currentStock: 0,
        minStockLevel: 20,
        unitCost: sop.costPerUnit,
        wholesalePrice: sop.wholesalePrice,
        retailMRP: sop.retailMRP,
        unitOfSale: sop.unitOfSale
      });
    }

    setDb(prev => ({ ...prev, sops: updatedSops, finishedGoods: updatedFinished }));
  };

  const handleDeleteSOP = (id: string) => {
    setDb(prev => ({
      ...prev,
      sops: prev.sops.filter(s => s.id !== id)
    }));
  };

  // Handler for Batch Production Execution
  const handleExecuteBatch = (
    batch: ProductionBatch,
    consumedMaterials: { id: string; qty: number }[],
    finishedGoodUpdate: { sopId: string; qty: number; unitCost: number }
  ) => {
    // 1. Deduct raw materials stock
    const updatedRaw = db.rawMaterials.map(rm => {
      const consumed = consumedMaterials.find(c => c.id === rm.id);
      if (consumed) {
        return {
          ...rm,
          currentStock: Math.max(0, rm.currentStock - consumed.qty)
        };
      }
      return rm;
    });

    // 2. Increment finished goods stock
    const updatedFinished = db.finishedGoods.map(fg => {
      if (fg.sopId === finishedGoodUpdate.sopId) {
        return {
          ...fg,
          currentStock: fg.currentStock + finishedGoodUpdate.qty,
          unitCost: finishedGoodUpdate.unitCost,
          lastProducedDate: batch.producedDate
        };
      }
      return fg;
    });

    setDb(prev => ({
      ...prev,
      rawMaterials: updatedRaw,
      finishedGoods: updatedFinished,
      batches: [batch, ...prev.batches]
    }));
  };

  // Handlers for Finished Goods
  const handleUpdateFinishedPrices = (id: string, wholesalePrice: number, retailMRP: number) => {
    setDb(prev => ({
      ...prev,
      finishedGoods: prev.finishedGoods.map(f =>
        f.id === id ? { ...f, wholesalePrice, retailMRP } : f
      )
    }));
  };

  const handleAdjustFinishedStock = (id: string, newStock: number, reason: string) => {
    setDb(prev => ({
      ...prev,
      finishedGoods: prev.finishedGoods.map(f =>
        f.id === id ? { ...f, currentStock: newStock } : f
      )
    }));
  };

  // Handlers for Sales
  const handleRecordSale = (
    invoice: SaleInvoice,
    deductedStock: { id: string; qty: number }[]
  ) => {
    // Deduct finished goods stock
    const updatedFinished = db.finishedGoods.map(fg => {
      const sold = deductedStock.find(s => s.id === fg.id);
      if (sold) {
        return {
          ...fg,
          currentStock: Math.max(0, fg.currentStock - sold.qty)
        };
      }
      return fg;
    });

    setDb(prev => ({
      ...prev,
      finishedGoods: updatedFinished,
      sales: [invoice, ...prev.sales]
    }));
  };

  // Handlers for Suppliers
  const handleSaveSupplier = (supplier: Supplier) => {
    const existingIndex = db.suppliers.findIndex(s => s.id === supplier.id);
    let updated = [...db.suppliers];
    if (existingIndex > -1) {
      updated[existingIndex] = supplier;
    } else {
      updated.unshift(supplier);
    }
    setDb(prev => ({ ...prev, suppliers: updated }));
  };

  const handleDeleteSupplier = (id: string) => {
    setDb(prev => ({
      ...prev,
      suppliers: prev.suppliers.filter(s => s.id !== id)
    }));
  };

  // Handlers for Business Profile & Reset
  const handleSaveProfile = (profile: BusinessProfile) => {
    setDb(prev => ({ ...prev, profile }));
  };

  const handleResetDemoData = () => {
    const freshDb = resetToDemoDatabase();
    setDb(freshDb);
  };

  const handleImportDatabase = (importedDb: AppDatabase) => {
    setDb(importedDb);
  };

  // Quick navigation triggers
  const handleOpenQuickSale = () => {
    setCurrentTab('sales');
  };

  const handleOpenQuickProduction = (sopId?: string) => {
    setPreloadedSopId(sopId);
    setCurrentTab('production');
  };

  const handleOpenInwardPurchase = (rawMaterialId?: string) => {
    setPreloadedRawMatId(rawMaterialId);
    setCurrentTab('raw-materials');
  };

  const lowStockCount = db.rawMaterials.filter(m => m.currentStock <= m.minReorderLevel).length;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col selection:bg-emerald-500 selection:text-white">
      {/* Top Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={tab => {
          setCurrentTab(tab);
          setPreloadedSopId(undefined);
          setPreloadedRawMatId(undefined);
        }}
        profile={db.profile}
        lowStockCount={lowStockCount}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenQuickSale={handleOpenQuickSale}
        onOpenQuickProduction={() => handleOpenQuickProduction()}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'dashboard' && (
          <Dashboard
            rawMaterials={db.rawMaterials}
            sops={db.sops}
            finishedGoods={db.finishedGoods}
            batches={db.batches}
            sales={db.sales}
            profile={db.profile}
            onNavigate={setCurrentTab}
            onOpenQuickSale={handleOpenQuickSale}
            onOpenQuickProduction={handleOpenQuickProduction}
            onOpenInwardPurchase={handleOpenInwardPurchase}
            onViewInvoice={inv => setActiveInvoiceModal(inv)}
          />
        )}

        {currentTab === 'raw-materials' && (
          <RawMaterialsManager
            rawMaterials={db.rawMaterials}
            suppliers={db.suppliers}
            purchases={db.purchases}
            onSaveRawMaterial={handleSaveRawMaterial}
            onDeleteRawMaterial={handleDeleteRawMaterial}
            onRecordPurchase={handleRecordPurchase}
            onAdjustStock={handleAdjustRawStock}
            selectedPreloadId={preloadedRawMatId}
            onClearPreloadId={() => setPreloadedRawMatId(undefined)}
          />
        )}

        {currentTab === 'product-sop' && (
          <ProductSOPManager
            sops={db.sops}
            rawMaterials={db.rawMaterials}
            onSaveSOP={handleSaveSOP}
            onDeleteSOP={handleDeleteSOP}
            onStartProduction={sopId => handleOpenQuickProduction(sopId)}
          />
        )}

        {currentTab === 'production' && (
          <ProductionBatchManager
            batches={db.batches}
            sops={db.sops}
            rawMaterials={db.rawMaterials}
            finishedGoods={db.finishedGoods}
            onExecuteBatch={handleExecuteBatch}
            preselectedSopId={preloadedSopId}
            onClearPreselectedSop={() => setPreloadedSopId(undefined)}
          />
        )}

        {currentTab === 'finished-goods' && (
          <FinishedGoodsManager
            finishedGoods={db.finishedGoods}
            sops={db.sops}
            onStartProduction={sopId => handleOpenQuickProduction(sopId)}
            onUpdatePrices={handleUpdateFinishedPrices}
            onAdjustStock={handleAdjustFinishedStock}
          />
        )}

        {currentTab === 'sales' && (
          <SalesManager
            finishedGoods={db.finishedGoods}
            sales={db.sales}
            profile={db.profile}
            onRecordSale={handleRecordSale}
            onViewInvoice={inv => setActiveInvoiceModal(inv)}
          />
        )}

        {currentTab === 'suppliers' && (
          <SuppliersManager
            suppliers={db.suppliers}
            purchases={db.purchases}
            onSaveSupplier={handleSaveSupplier}
            onDeleteSupplier={handleDeleteSupplier}
            onInwardFromSupplier={supId => {
              setCurrentTab('raw-materials');
            }}
          />
        )}
      </main>

      {/* Invoice Viewer & WhatsApp Modal */}
      {activeInvoiceModal && (
        <InvoiceModal
          invoice={activeInvoiceModal}
          profile={db.profile}
          onClose={() => setActiveInvoiceModal(null)}
        />
      )}

      {/* Business Settings & Backup Modal */}
      {isSettingsOpen && (
        <SettingsModal
          profile={db.profile}
          onSaveProfile={handleSaveProfile}
          onResetDemoData={handleResetDemoData}
          onImportDatabase={handleImportDatabase}
          fullDatabase={db}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {/* Subtle Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-4 border-t border-slate-800 mt-auto print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-200">{db.profile.name}</span>
            <span>•</span>
            <span className="text-slate-400">Cottage Industry Management & Costing OS</span>
          </div>
          <div className="text-slate-400">
            INR (₹) Currency • Food & Chemical Manufacturing Systems
          </div>
        </div>
      </footer>
    </div>
  );
}
