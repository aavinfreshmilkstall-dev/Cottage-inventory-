export type ProductCategory = 'Food' | 'Chemical' | 'All';

export type RawMaterialCategory = 'Food Ingredient' | 'Chemical Ingredient' | 'Packaging' | 'Label & Cap' | 'Other';

export type UnitType = 'kg' | 'g' | 'L' | 'ml' | 'pcs' | 'pouch' | 'bottle' | 'box' | 'meter' | 'roll';

export interface RawMaterial {
  id: string;
  name: string;
  category: RawMaterialCategory;
  unit: UnitType;
  currentStock: number;
  minReorderLevel: number;
  costPerUnit: number; // in INR
  supplierId?: string;
  supplierName?: string;
  lastPurchasedDate?: string;
  notes?: string;
}

export interface BOMItem {
  rawMaterialId: string;
  rawMaterialName: string;
  unit: UnitType;
  quantityPerBatch: number; // quantity needed for the base batch size
  unitCost: number; // current or custom cost per unit
  totalCost: number; // quantityPerBatch * unitCost
  isPackaging?: boolean;
}

export interface ProductSOP {
  id: string;
  name: string;
  code: string;
  category: 'Food' | 'Chemical';
  packageSize: string; // e.g. "500 ml", "1 Liter", "250 grams", "1 kg"
  baseBatchOutputUnits: number; // e.g. 50 bottles per batch
  unitOfSale: string; // "bottle", "pouch", "container"
  
  // Costing components for 1 base batch:
  bomItems: BOMItem[]; // Raw materials + packaging
  laborCostPerBatch: number; // Labor / workers cost for batch
  electricityOverheadPerBatch: number; // Power/gas/fuel/rent overhead
  wastagePercent: number; // e.g. 3% for spillage/evaporation
  
  // Computed totals (cached for quick reference):
  totalRawCost: number;
  totalPackagingCost: number;
  totalBatchCost: number;
  costPerUnit: number; // Base Cost of Price (CoP)
  
  // Pricing Strategy:
  wholesaleMarginPercent: number; // e.g. 25%
  wholesalePrice: number; // Cost + margin
  retailMarginPercent: number; // e.g. 50%
  retailMRP: number; // Recommended MRP
  
  // SOP Guide / Instructions:
  preparationSteps: string[];
  safetyNotes?: string;
  shelfLife?: string;
  updatedAt: string;
}

export interface ProductionBatch {
  id: string;
  batchNumber: string;
  sopId: string;
  productName: string;
  category: 'Food' | 'Chemical';
  batchSizeUnits: number; // number of finished items produced
  costPerUnit: number;
  totalBatchCost: number;
  producedDate: string;
  status: 'Completed' | 'In Progress' | 'Cancelled';
  materialsConsumed: {
    rawMaterialId: string;
    rawMaterialName: string;
    quantityUsed: number;
    unit: UnitType;
    unitCost: number;
    totalCost: number;
  }[];
  notes?: string;
  operatorName?: string;
}

export interface FinishedGood {
  id: string;
  sopId: string;
  name: string;
  code: string;
  category: 'Food' | 'Chemical';
  packageSize: string;
  currentStock: number; // in units/bottles/pouches
  minStockLevel: number;
  unitCost: number; // Latest Cost of Price
  wholesalePrice: number;
  retailMRP: number;
  unitOfSale: string;
  lastProducedDate?: string;
}

export interface PurchaseRecord {
  id: string;
  purchaseNumber: string;
  date: string;
  supplierId: string;
  supplierName: string;
  supplierPhone?: string;
  items: {
    rawMaterialId: string;
    rawMaterialName: string;
    unit: UnitType;
    quantity: number;
    costPerUnit: number;
    totalAmount: number;
  }[];
  totalAmount: number;
  paymentStatus: 'Paid' | 'Pending' | 'Partial';
  invoiceNumber?: string;
  notes?: string;
}

export interface SaleItem {
  finishedGoodId: string;
  productName: string;
  packageSize: string;
  quantity: number;
  unitPrice: number; // Selling rate
  unitCost: number; // For profit calculation
  unitOfSale: string;
  totalAmount: number;
  totalProfit: number;
}

export interface SaleInvoice {
  id: string;
  invoiceNumber: string;
  date: string;
  customerName: string;
  customerPhone?: string;
  outletType: 'Direct Outlet' | 'Retail Customer' | 'Wholesale Buyer' | 'Local Shop';
  pricingType: 'Retail MRP' | 'Wholesale' | 'Custom';
  items: SaleItem[];
  subtotal: number;
  discountAmount: number;
  taxPercent: number; // 0, 5, 12, 18
  taxAmount: number;
  grandTotal: number;
  totalCost: number;
  grossProfit: number;
  paymentMethod: 'Cash' | 'UPI / GPay / PhonePe' | 'Card' | 'Bank Transfer' | 'Credit (Pending)';
  paymentStatus: 'Paid' | 'Pending';
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson?: string;
  phone: string;
  email?: string;
  address?: string;
  categorySupplied: string;
  notes?: string;
}

export interface BusinessProfile {
  name: string;
  tagline: string;
  phone: string;
  whatsappNumber: string;
  address: string;
  outletLocation: string;
  upiId: string;
  gstNumber?: string;
  fssaiNumber?: string;
  invoiceFooterNote: string;
}
